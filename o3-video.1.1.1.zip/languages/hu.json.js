[{
	"no_support_msg": "Az ön böngészője nem támogatja a HTML5 videó lejátszót vagy hiányzik a videó fájlhoz szügséges dekóder.<br><a href=\"//www.google.com/intl/hu/chrome/\" target=\"_blank\">Kattintson ide a Google Chrome letöltéséhez.</a><br><br>A böngészője nem rendelkezik az Adobe Flash lejátszóval.<br><a href=\"//get.adobe.com/flashplayer/\" target=\"_blank\">Kattintson ide az Adobe Flash lejátszót letöltéséhez.</a>.",
	"play_video": "Lejátszás",
	"pause_video": "Lejátszás szüneteltetése",
	"mute": "Némítás",
	"unmute": "Némítás feloldása",
	"loop_video": "Ismétlés",
	"dont_loop_video": "Ismétlés feloldása",
	"show_controls": "Vezérlõk megjelenítése",
	"hide_controls": "Vezérlõk eltüntetése",
	"save_video_as": "Videó mentése másként...",
	"copy_video_url": "Videó URL-címének másolása",
	"open_video_in_new_tab": "Videó megnyitása új lapon"
}]