[{
	"no_support_msg": "Din browser understøtter ikke video-tag eller mangler codec til denne video-fil.<br><a href=\"//www.google.com/intl/da/chrome/\" target=\"_blank\">Klik her for at downloade Google Chrome.</a><br><br>Din browser har ikke Adobe Flash Player installeret.<br><a href=\"//get.adobe.com/flashplayer/\" target=\"_blank\">Klik her for at downloade Adobe Flash Player.</a>.",
	"play_video": "Spil",
	"pause_video": "Pause",
	"mute": "Slå lyden fra",
	"unmute": "Slå lyden til",
	"loop_video": "Sløjfe",
	"dont_loop_video": "Ikke sløjfe",
	"show_controls": "Vis knapper",
	"hide_controls": "Skjul knapper",
	"save_video_as": "Gem video som...",
	"copy_video_url": "Kopier videoens webadresse",
	"open_video_in_new_tab": "Åbn video på ny fane"
}]