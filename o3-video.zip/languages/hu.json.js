/**
* O3 video player danish language translation
*
* Cross browser javascript video player
* Released under the MIT license
*
* @author Zoltan Fischer 
* @project https://github.com/zoli-fischer/o3-video 
* @license https://github.com/zoli-fischer/o3-video/blob/master/LICENSE
*/
[{
	"no_support_msg": "Az ön böngészője nem támogatja a HTML5 videó lejátszót vagy hiányzik a videó fájlhoz szügséges dekóder.<br><a href=\"//www.google.com/intl/hu/chrome/\" target=\"_blank\">Kattintson ide a Google Chrome letöltéséhez.</a><br><br>A böngészője nem rendelkezik az Adobe Flash lejátszóval.<br><a href=\"//get.adobe.com/flashplayer/\" target=\"_blank\">Kattintson ide az Adobe Flash lejátszót letöltéséhez.</a>."
}]